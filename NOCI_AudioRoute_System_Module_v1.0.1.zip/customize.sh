SKIPUNZIP=0
ui_print " "
ui_print "  PROJECT NOCI :: AudioRoute System"
ui_print "  priv-app + privapp-permissions + sysconfig"
ui_print " "
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
